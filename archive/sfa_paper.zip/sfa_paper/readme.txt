Signal Field Attention - Technical Report PDF
Author: Taicu Team
Date: June 2026
License: MIT (code), CC BY 4.0 (paper)
Repository: https://github.com/CN-QN1-dalin/signal-field-attention

This paper introduces Signal Field Attention (SFA), a dual-channel attention
mechanism achieving 4.16x decoding speedup and 248x KV cache compression.
